
function searchCourses() {
  const input = document.getElementById("search").value.toLowerCase();
  const items = document.querySelectorAll(".course");

  items.forEach(item => {
    item.style.display = item.textContent.toLowerCase().includes(input)
      ? "block"
      : "none";
  });
}
